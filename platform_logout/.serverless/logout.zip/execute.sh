npm install --save
serverless deploy --stage dev -v
/tmp/aws-apigateway-importer/aws-api-import.sh --update en0ikzjf13  --deploy dev swagger/swagger.json
