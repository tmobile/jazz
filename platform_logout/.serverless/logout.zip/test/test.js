const assert = require('chai').assert;
const index = require('../index');

describe('Sample', function() {
  it('tests handler', function(done) {

    // Add your test cases here.
    assert(true);
    done();
  });
});
