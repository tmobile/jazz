export { NgSlimScrollModule } from './src/ngx-slimscroll/module/ngx-slimscroll.module';
export * from './src/ngx-slimscroll/classes/slimscroll-options.class';
